_USERNAME = ''
_PASSWORD = ''

def get_username():
    return _USERNAME

def get_password():
    return _PASSWORD
