from password import *

# User credentials
EMAIL = get_username()
PASSWORD = get_password()

numOfScroll = 3
grab_comment = False