PAGE_LINKS = [
    'https://www.facebook.com/Grameenphone',
    'https://www.facebook.com/RobiFanz',
    'https://www.facebook.com/airtelbuzz/',
    'https://www.facebook.com/10minuteschool/',
    'https://web.facebook.com/techlandbd/',
]